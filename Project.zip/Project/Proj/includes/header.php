<?php
session_start();
require_once 'includes/databse.php';
require_once 'includes/register-inc.php'

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Document</title>
<link rel="stylesheet" type="text/css" href="style.css">


</head>
<body>
	<header>
		<nav> 
			<ul> 
				<li><a href="index.php">Home</a></li>
				<li><a href="login.php">login</a>  </li>	
				<li><a href="register.php">register</a>  </li>
				


			</ul>

		</nav>
	</header>
<?php