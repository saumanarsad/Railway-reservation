<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title>Document</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
<div>
	<h1>Get in touch</h1>
	<p>Please fill in the field</p>
	<form action="contact.php" method="post">
		<input type="text" name="name" placeholder="Full name">
        <input type="text" name="email" placeholder="email">
		<input type="text" name="subject" placeholder="Subject">
        <textarea name="message" placeholder="Enter message"></textarea>
        <button type="submit" name="submit">Send email</button>




	</form>
</div>

</body>
</html>