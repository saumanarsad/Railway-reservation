<header>
	<nav>
		<ul>
			<li><a href=" head.php">Home
             <li><a href="About.php">About</a></li>
             <li><a href="Contact.php">Contact</a></li>
			</a></li>
		</ul>
	</nav>
</header>
