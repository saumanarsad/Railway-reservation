<?php 
function myfunction(){
	echo "Hello world";
}

?>