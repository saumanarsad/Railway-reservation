<?php
include 'Includes/header.php'; 
?>
<h1>Welcome to contact</h1>
<?php
include 'Includes/footer.php';
?>