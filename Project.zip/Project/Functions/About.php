<?php
include 'Includes/header.php'; 
?>
<h1>Welcome to about page</h1>
<?php
include 'Includes/footer.php';
?>